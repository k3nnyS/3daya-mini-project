package com.eksad.expro.controller;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.eksad.expro.model.MenuModel;
import com.eksad.expro.service.MenuService;

@Controller
public class ApiMenuController {
	private Log log = LogFactory.getLog(getClass());
	
	@Autowired
	private MenuService service;
	
	@RequestMapping(value = "api/menu/", method = RequestMethod.GET)
	public ResponseEntity<List<MenuModel>> list(){
		ResponseEntity<List<MenuModel>> result = null;
		try {
			List<MenuModel> list = this.service.getList();
			result = new ResponseEntity<List<MenuModel>>(list, HttpStatus.OK);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<List<MenuModel>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	@RequestMapping(value ="api/menu/search/{katakunci}", method = RequestMethod.GET)
	public ResponseEntity<List<MenuModel>> search(@PathVariable("katakunci") String cari){
		ResponseEntity<List<MenuModel>> result = null;
		try {
			List<MenuModel> list = this.service.search(cari);
			result = new ResponseEntity<List<MenuModel>>(list, HttpStatus.OK);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<List<MenuModel>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	@RequestMapping(value = "api/menu/{menuId}", method = RequestMethod.GET)
	public ResponseEntity<MenuModel> getById(@PathVariable("menuId") int vId){
		ResponseEntity<MenuModel> result = null;
		try {
			MenuModel menu = this.service.getById(vId);
			result = new ResponseEntity<MenuModel>(menu, HttpStatus.OK);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<MenuModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	@RequestMapping(value = "api/menu/", method = RequestMethod.POST)
	public ResponseEntity<MenuModel> postInsert(@RequestBody MenuModel item){
		ResponseEntity<MenuModel> result = null;
		try {
			this.service.insert(item);
			result = new ResponseEntity<MenuModel>(item, HttpStatus.CREATED);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<MenuModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	@RequestMapping(value ="api/menu/", method = RequestMethod.PUT)
	public ResponseEntity<MenuModel> putUpdate(@RequestBody MenuModel item){
		ResponseEntity<MenuModel> result = null;
		try {
			this.service.update(item);
			result = new ResponseEntity<MenuModel>(item, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<MenuModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
	
	@RequestMapping(value ="api/menu/{catId}", method = RequestMethod.DELETE)
	public ResponseEntity<MenuModel> delApi(@PathVariable("catId") Integer vid){
		ResponseEntity<MenuModel> result = null;
		try {
			MenuModel item = this.service.getById(vid);
			if(item != null) {
				this.service.delete(item);
				result = new ResponseEntity<MenuModel>(item, HttpStatus.ACCEPTED);
			} else {
				result = new ResponseEntity<MenuModel>(HttpStatus.NO_CONTENT);
			}
		} catch (Exception e) {
			log.debug(e.getMessage(), e);
			result = new ResponseEntity<MenuModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return result;
	}
}
